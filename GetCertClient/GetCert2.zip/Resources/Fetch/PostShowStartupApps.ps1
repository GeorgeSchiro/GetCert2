Get-ItemProperty -Path "HKLM:\Software\Microsoft\Windows\CurrentVersion\Run"
