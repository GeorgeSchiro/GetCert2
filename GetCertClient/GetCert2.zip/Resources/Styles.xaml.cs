using System.Windows;
using System.Windows.Input;


namespace GetCert2
{
    partial class Styles : ResourceDictionary
    { 
        public Styles()
        {
            InitializeComponent();
        }

        // Event handlers go here.
    }
}
